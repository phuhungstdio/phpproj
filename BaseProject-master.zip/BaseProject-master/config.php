<?php
class Config{
    
    static public $urlbase = "http://localhost/BasePHP/";
}
?>